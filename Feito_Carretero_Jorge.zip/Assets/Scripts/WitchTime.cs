using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class WitchTime : MonoBehaviour
{
    //public AudioClip WitchTime;
    //private bool isSlowed = false;
    //public float howSlow = 0.25f;
    ////Update is called once per frame
    //void Update()
    //{
    //    if (Input.GetKeyDown(KeyCode.Mouse1))
    //    {
    //        StartCoroutine(SlowDown);
    //    }
    //}
    //private IEnumerator SlowDown()
    //{
    //    isSlowed = true;
    //    Time.timeScale = howSlow;
    //    Time.fixedDeltaTime = 0.02f * Time.timeScale;
    //    AudioManager.instance.PlayAudio(WitchTime, "WitchTime", true);
    //    yield return new WaitForSeconds(howSlow);
    //    Time.timeScale = 1;
    //    Time.fixedDeltaTime = 0.02f;
    //    isSlowed = false;
    //}
}
